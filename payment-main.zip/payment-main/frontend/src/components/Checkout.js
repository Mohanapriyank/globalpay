import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

function Checkout() {
    // Static cart items
    const cartItems = [
        { id: 1, name: "Static Product 1", price: 50 },
        { id: 2, name: "Static Product 2", price: 100 }
    ];

    const [paymentDetails, setPaymentDetails] = useState({
        cardNumber: "1234-5678-9012-3456",
        expiryDate: "12/25",
        cvv: "123"
    });

    const [region, setRegion] = useState("USA");
    const navigate = useNavigate();

    const handleCheckout = async () => {
        try {
            // Calculate total amount
            const totalAmount = cartItems.reduce((acc, product) => acc + product.price, 0);

            // Tax calculation based on region
            const taxRates = {
                USA: 0.07, // 7% for USA
                Canada: 0.05, // 5% for Canada
                UK: 0.2 // 20% for UK
            };
            const taxRate = taxRates[region] || 0;
            const tax = totalAmount * taxRate;
            const totalWithTax = totalAmount + tax;

            // Mock invoice generation
            const invoice = {
                _id: "123456789",
                region,
                createdAt: new Date().toISOString(),
                products: cartItems,
                paymentDetails: {
                    cardNumber: paymentDetails.cardNumber.slice(-4) // Last 4 digits only
                },
                total: totalWithTax
            };

            // For demonstration, no API call is made; just navigate to the Invoice page
            alert("Order placed successfully!");
            navigate("/invoice", { state: { invoice } });
        } catch (error) {
            console.error("Error placing order", error);
            alert("There was an error placing your order.");
        }
    };

    return (
        <div className="max-w-2xl mx-auto p-6 bg-white border rounded-lg shadow-md">
            <h2 className="text-2xl font-bold mb-4 text-center">Checkout</h2>
            <div>
                <h3 className="text-xl font-semibold mb-2">Cart Items:</h3>
                {cartItems.map(item => (
                    <div key={item.id} className="flex justify-between mb-2 border-b pb-2">
                        <p className="text-gray-800">{item.name}</p>
                        <p className="text-gray-800">${item.price.toFixed(2)}</p>
                    </div>
                ))}
                <h4 className="text-lg font-semibold mt-4">
                    Total: ${cartItems.reduce((acc, item) => acc + item.price, 0).toFixed(2)}
                </h4>

                <div className="mt-4">
                    <button 
                        onClick={handleCheckout} 
                        className="w-full py-2 bg-blue-500 text-white rounded hover:bg-blue-600 transition duration-200"
                    >
                        Place Order
                    </button>
                </div>
            </div>
        </div>
    );
}

export default Checkout;
