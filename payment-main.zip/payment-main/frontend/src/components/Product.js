import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

function Product({ cartItems = [], setCartItems }) { // Default value for cartItems
    // Static product data
    const [products] = useState([
        {
            _id: "1",
            name: "Product 1",
            description: "This is the description for Product 1.",
            price: 10.0,
            imageUrl: "https://via.placeholder.com/100",
        },
        {
            _id: "2",
            name: "Product 2",
            description: "This is the description for Product 2.",
            price: 15.0,
            imageUrl: "https://via.placeholder.com/100",
        },
        {
            _id: "3",
            name: "Product 3",
            description: "This is the description for Product 3.",
            price: 20.0,
            imageUrl: "https://via.placeholder.com/100",
        },
    ]);

    const navigate = useNavigate();

    // Function to add a product to the cart
    const handleAddToCart = (product) => {
        const userId = localStorage.getItem("userId");

        if (!userId) {
            alert("You must be logged in to add items to your cart.");
            return;
        }

        // Check if the product is already in the cart
        const existingProductIndex = cartItems.findIndex((item) => item._id === product._id);
        if (existingProductIndex > -1) {
            // Update the quantity if the product is already in the cart
            const updatedCart = cartItems.map((item) =>
                item._id === product._id ? { ...item, quantity: item.quantity + 1 } : item
            );
            setCartItems(updatedCart);
        } else {
            // Add the product to the cart with a quantity of 1
            setCartItems([...cartItems, { ...product, quantity: 1 }]);
        }

        alert(`${product.name} has been added to your cart!`);
        navigate("/cart"); // Navigate to the cart page
    };

    return (
        <div className="container mx-auto p-4">
            <h1 className="text-3xl font-bold mb-6">Products</h1>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
                {products.map((product) => (
                    <div key={product._id} className="bg-white border rounded-lg shadow-lg p-4">
                        <img src={product.imageUrl} alt={product.name} className="w-full h-32 object-cover mb-4 rounded" />
                        <h2 className="text-xl font-semibold">{product.name}</h2>
                        <p className="text-gray-600 mb-2">{product.description}</p>
                        <p className="text-lg font-bold text-blue-500">${product.price.toFixed(2)}</p>
                        <button
                            onClick={() => handleAddToCart(product)}
                            className="w-full mt-4 p-2 bg-blue-500 text-white rounded hover:bg-blue-600 transition duration-200"
                        >
                            Add to Cart
                        </button>
                    </div>
                ))}
            </div>
        </div>
    );
}

export default Product;
