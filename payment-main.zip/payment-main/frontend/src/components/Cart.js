import React from "react";
import { useNavigate } from "react-router-dom";

function Cart({ cartItems = [], setCartItems }) {
    const navigate = useNavigate();

    const handleRemoveItem = (productId) => {
        setCartItems(cartItems.filter(item => item._id !== productId));
    };

    const handleCheckout = () => {
        navigate("/checkout"); // Navigate to the checkout page
    };

    return (
        <div className="max-w-2xl mx-auto p-6 bg-white border rounded-lg shadow-md">
            <h2 className="text-2xl font-bold mb-4">Your Cart</h2>
            {cartItems.length === 0 ? (
                <p className="text-center text-gray-500">Your cart is empty.</p>
            ) : (
                <div>
                    {cartItems.map(item => (
                        <div key={item._id} className="flex justify-between items-center border-b pb-4 mb-4">
                            <div>
                                <h4 className="text-lg font-semibold">{item.name}</h4>
                                <p className="text-gray-700">Price: ${item.price.toFixed(2)}</p>
                                <p className="text-gray-700">Quantity: {item.quantity}</p>
                            </div>
                            <button 
                                onClick={() => handleRemoveItem(item._id)} 
                                className="ml-4 px-4 py-2 bg-red-500 text-white rounded hover:bg-red-600 transition duration-200"
                            >
                                Remove
                            </button>
                        </div>
                    ))}
                    <button 
                        className="mt-6 w-full py-2 bg-blue-500 text-white rounded hover:bg-blue-600 transition duration-200" 
                        onClick={handleCheckout}
                    >
                        Proceed to Checkout
                    </button>
                </div>
            )}
        </div>
    );
}

export default Cart;
