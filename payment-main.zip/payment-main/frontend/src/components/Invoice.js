import React from "react";
import { useLocation } from "react-router-dom";
import jsPDF from "jspdf";

function Invoice() {
    const location = useLocation();
    const { invoice } = location.state || {};

    if (!invoice) {
        return <p className="text-center text-red-500">No invoice data available. Please place an order first.</p>;
    }

    const downloadPDF = () => {
        const doc = new jsPDF();
        doc.text("Invoice", 10, 10);
        doc.text(`Order ID: ${invoice._id}`, 10, 20);
        doc.text(`Region: ${invoice.region}`, 10, 30);
        doc.text(`Date: ${new Date(invoice.createdAt).toLocaleDateString()}`, 10, 40);
        doc.text("Items:", 10, 50);
        invoice.products.forEach((product, index) => {
            doc.text(`${product.name} - $${product.price.toFixed(2)}`, 10, 60 + index * 10);
        });
        doc.text(`Total (including tax): $${invoice.total.toFixed(2)}`, 10, 100);
        doc.save("invoice.pdf");
    };

    return (
        <div className="max-w-2xl mx-auto p-6 bg-white border rounded-lg shadow-md">
            <h2 className="text-2xl font-bold mb-4 text-center">Invoice</h2>
            <div className="mb-6">
                <h4 className="text-lg font-semibold">Order ID: {invoice._id}</h4>
                <p className="text-gray-700">Region: {invoice.region}</p>
                <p className="text-gray-700">Date: {new Date(invoice.createdAt).toLocaleDateString()}</p>
            </div>

            <h3 className="text-xl font-semibold mb-2">Items:</h3>
            {invoice.products.map((product, index) => (
                <div key={index} className="flex justify-between mb-2">
                    <p className="text-gray-800">{product.name}</p>
                    <p className="text-gray-800">Price: ${product.price.toFixed(2)}</p>
                </div>
            ))}

            <h3 className="text-xl font-semibold mt-4">Payment Details:</h3>
            <div className="border-t mt-2 pt-2">
                <p className="text-gray-700">Card Number: **** **** **** {invoice.paymentDetails.cardNumber}</p>
                <p className="text-gray-700">Total (including tax): ${invoice.total.toFixed(2)}</p>
            </div>

            <button 
                onClick={downloadPDF}
                className="mt-4 w-full py-2 bg-blue-500 text-white rounded hover:bg-blue-600 transition duration-200"
            >
                Download PDF
            </button>
        </div>
    );
}

export default Invoice;
