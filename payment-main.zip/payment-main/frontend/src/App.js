import React, { useEffect, useState } from "react";
import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import Login from "./components/Login";
import Signup from "./components/Signup";
import Product from "./components/Product";
import Cart from "./components/Cart";
import Checkout from "./components/Checkout"; // Assuming you have a Checkout component
import Invoice from "./components/Invoice"; // Assuming you have an Invoice component

function App() {
    const [cartItems, setCartItems] = useState([]); // Initialize cartItems as an empty array
    const [isAuthenticated, setIsAuthenticated] = useState(false);

    useEffect(() => {
        // Check if the user is authenticated by looking for a token
        const token = localStorage.getItem("token");
        if (token) {
            setIsAuthenticated(true);
        }
    }, []);

    return (
        <Router>
            <Routes>
                {/* Redirect to products if authenticated, otherwise go to login */}
                <Route path="/" element={<Navigate to={isAuthenticated ? "/products" : "/login"} />} />
                
                {/* Public Routes */}
                <Route path="/login" element={<Login onLogin={() => setIsAuthenticated(true)} />} />
                <Route path="/signup" element={<Signup />} />

                {/* Protected Routes */}
                {isAuthenticated ? (
                    <>
                        <Route path="/products" element={<Product cartItems={cartItems} setCartItems={setCartItems} />} />
                        <Route path="/cart" element={<Cart cartItems={cartItems} setCartItems={setCartItems} />} />
                        <Route path="/checkout" element={<Checkout />} />
                        <Route path="/invoice" element={<Invoice />} />
                    </>
                ) : (
                    // Redirect unauthorized access attempts to login page
                    <Route path="*" element={<Navigate to="/login" />} />
                )}
            </Routes>
        </Router>
    );
}

export default App;
