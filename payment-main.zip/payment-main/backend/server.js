const express = require("express");
const dotenv = require("dotenv");
const connectDB = require("./config/db");
const authRoutes = require("./routes/authRoutes");
const productRoutes = require("./routes/productRoutes");
const orderRoutes = require("./routes/orderRoutes");
const cartRoutes = require("./routes/cartRoutes"); // Import cartRoutes
const cors = require("cors");

dotenv.config();
connectDB();

const app = express();
app.use(cors());
app.use(express.json());

app.use("/api/auth", authRoutes);
app.use("/api/products", productRoutes);
app.use("/api/orders", orderRoutes);
app.use("/api/cart", cartRoutes); // Use cartRoutes for /api/cart

app.listen(5000, () => console.log("Server running on port 5000"));
// Example Express.js backend route
app.post('/api/cart', async (req, res) => {
    const { userId, product } = req.body;

    if (!userId || !product) {
        return res.status(400).json({ error: 'User ID and product details are required.' });
    }

    try {
        // Assume you have a database function to add the product to the cart
        await addToCart(userId, product);
        res.status(200).json({ message: 'Product added to cart successfully.' });
    } catch (error) {
        console.error('Error adding product to cart:', error);
        res.status(500).json({ error: 'Failed to add item to cart' });
    }
});
