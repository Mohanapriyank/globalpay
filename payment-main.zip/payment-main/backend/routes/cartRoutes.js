const express = require("express");
const router = express.Router();
const Cart = require("../models/Cart");

// Add an item to the cart
router.post("/", async (req, res) => {
    try {
        const { userId, product } = req.body;

        // Find the cart for the user, or create a new one if it doesn't exist
        let cart = await Cart.findOne({ userId });
        if (!cart) {
            cart = new Cart({ userId, products: [product] });
        } else {
            // Add product to the existing cart
            const productIndex = cart.products.findIndex(p => p.productId.equals(product.productId));
            if (productIndex > -1) {
                cart.products[productIndex].quantity += product.quantity;
            } else {
                cart.products.push(product);
            }
        }

        await cart.save();
        res.status(200).json(cart);
    } catch (error) {
        res.status(500).json({ error: "Failed to add item to cart" });
    }
});

module.exports = router;
