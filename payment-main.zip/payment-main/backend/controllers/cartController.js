const mongoose = require("mongoose");
const User = require("../models/User"); // Assuming you have a User model defined in the models folder
const Cart = require("../models/Cart"); // Assuming you have a Cart model defined in the models folder

const addToCart = async (req, res) => {
    const { userId, product } = req.body;

    // Validate inputs
    if (!userId || !product) {
        return res.status(400).json({ error: 'User ID and product are required.' });
    }

    try {
        console.log("Adding to cart for userId:", userId, "product:", product);

        // Validate userId
        if (!mongoose.Types.ObjectId.isValid(userId)) {
            return res.status(400).json({ error: 'Invalid user ID.' });
        }

        const user = await User.findById(userId);
        if (!user) {
            return res.status(404).json({ error: 'User not found' });
        }

        // Validate product data
        const { productId, name, price, quantity } = product;
        if (!productId || !name || !price || !quantity) {
            return res.status(400).json({ error: 'Product data is incomplete.' });
        }

        if (!mongoose.Types.ObjectId.isValid(productId)) {
            return res.status(400).json({ error: 'Invalid product ID.' });
        }

        // Find or create a cart for the user
        let cart = await Cart.findOne({ userId });
        if (!cart) {
            cart = new Cart({ userId, products: [] });
        }

        // Check if the product is already in the cart
        const existingProductIndex = cart.products.findIndex(p => p.productId.equals(productId));
        if (existingProductIndex > -1) {
            // Update the quantity if product already exists
            cart.products[existingProductIndex].quantity += quantity;
        } else {
            // Add new product to the cart
            cart.products.push({ productId, name, price, quantity });
        }

        // Save the cart
        await cart.save();
        return res.status(200).json(cart);
    } catch (err) {
        console.error("Error while adding to cart:", err);
        return res.status(500).json({ error: 'Failed to add item to cart' });
    }
};

module.exports = addToCart;
