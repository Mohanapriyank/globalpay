const Order = require("../models/Order"); // Import your Order model

// Example of a tax calculation function
const calculateTax = (region, totalAmount) => {
    const taxRates = {
        "Region1": 0.05, // 5% tax
        "Region2": 0.1,  // 10% tax
        // Add other regions and their tax rates
    };
    
    const taxRate = taxRates[region] || 0; // Default to 0 if region is not found
    return totalAmount * taxRate;
};

// Create Order Function
const createOrder = async (req, res) => {
    const { paymentDetails, region, products } = req.body;

    // Calculate total amount from products
    const totalAmount = products.reduce((acc, product) => acc + product.price, 0);
    
    // Calculate taxes based on region
    const tax = calculateTax(region, totalAmount);
    const totalWithTax = totalAmount + tax;

    const newOrder = new Order({
        userId: req.user.id, // Assuming you have user authentication
        products,
        region,
        paymentDetails,
        total: totalWithTax, // Save total amount including tax
    });

    try {
        await newOrder.save();
        res.status(201).json(newOrder);
    } catch (error) {
        console.error("Error creating order", error);
        res.status(500).json({ message: "Error creating order" });
    }
};

module.exports = {
    createOrder
};
